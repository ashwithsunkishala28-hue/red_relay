"use strict";

const sampleDonors = [
  { name: "Aarav", blood: "O+", city: "Kompally" },
  { name: "Meera", blood: "A+", city: "Maisammaguda" },
  { name: "Rahul", blood: "B+", city: "Medchal" },
  { name: "Ananya", blood: "AB+", city: "Hyderabad" },
  { name: "Kiran", blood: "O-", city: "Kukatpally" },
  { name: "Priya", blood: "B-", city: "Maisammaguda" },
  { name: "Dev", blood: "A-", city: "Medchal" },
  { name: "Sana", blood: "AB-", city: "Kompally" }
];

// Simplified ABO/Rh suggestion matrix: recipient -> compatible donor groups.
// Clinical compatibility must be confirmed by a blood bank.
const compatibility = {
  "O-": ["O-"],
  "O+": ["O-", "O+"],
  "A-": ["O-", "A-"],
  "A+": ["O-", "O+", "A-", "A+"],
  "B-": ["O-", "B-"],
  "B+": ["O-", "O+", "B-", "B+"],
  "AB-": ["O-", "A-", "B-", "AB-"],
  "AB+": ["O-", "O+", "A-", "A+", "B-", "B+", "AB-", "AB+"]
};

const STAGES = ["Pending verification", "Verified", "Donor matched", "Fulfilled"];
const $ = id => document.getElementById(id);

// Persistence (safe if storage is blocked or data is corrupt)
function load(key, fallback) {
  try {
    const data = JSON.parse(localStorage.getItem(key));
    return Array.isArray(data) ? data : fallback;
  } catch { return fallback; }
}
function save(key, value) {
  try { localStorage.setItem(key, JSON.stringify(value)); } catch { /* ignore */ }
}

let donors = load("redrelay.donors", [...sampleDonors]);
let requests = load("redrelay.requests", []);

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text; // textContent prevents XSS
  return node;
}

function showEmpty(container, text) {
  container.replaceChildren(el("p", "empty", text));
}

function displayDonors(list) {
  const container = $("donorList");
  if (list.length === 0) return showEmpty(container, "No matching sample profiles found.");

  container.replaceChildren(...list.map(donor => {
    const card = el("div", "donor-card");
    const top = el("div", "donor-top");
    top.append(el("span", "blood-badge", donor.blood), el("span", "available", "● SAMPLE PROFILE"));
    card.append(top, el("h3", "", donor.name), el("p", "", "⌖ " + donor.city),
      el("p", "", "Contact protected · Eligibility not verified"));
    return card;
  }));
}

function searchDonors() {
  const blood = $("bloodFilter").value;
  const city = $("cityFilter").value.trim().toLowerCase();
  let filtered = donors;

  if (blood) filtered = filtered.filter(d => compatibility[blood].includes(d.blood));
  if (city) filtered = filtered.filter(d => d.city.toLowerCase().includes(city));

  const note = blood ? ` compatible with ${blood}` : "";
  $("resultInfo").textContent =
    `${filtered.length} sample donor${filtered.length === 1 ? "" : "s"}${note} found.`;
  displayDonors(filtered);
}

function updateDonorCount() {
  $("donorCount").textContent = donors.length;
}

function countMatches(blood, city) {
  const c = city.toLowerCase();
  return donors.filter(d => compatibility[blood].includes(d.blood) &&
    d.city.toLowerCase().includes(c)).length;
}

function displayRequests() {
  const container = $("requestFeed");
  if (requests.length === 0)
    return showEmpty(container, "No demo requests yet. New requests will appear here.");

  container.replaceChildren(...requests.map((r, index) => {
    const card = el("article", "feed-card");
    const stages = el("div", "stages");
    stages.setAttribute("role", "img");
    stages.setAttribute("aria-label", `Stage ${r.stage + 1} of ${STAGES.length}: ${STAGES[r.stage]}`);
    STAGES.forEach((_, i) => stages.append(el("i", i <= r.stage ? "on" : "")));

    card.append(
      el("span", "feed-badge", `${r.blood} · ${STAGES[r.stage].toUpperCase()}`),
      el("h3", "", r.hospital),
      el("p", "", `${r.patient} · ${r.city} · ${r.units} unit(s)`),
      el("p", "meta", `${countMatches(r.blood, r.city)} compatible sample donor(s) in ${r.city}`),
      stages
    );

    if (r.stage < STAGES.length - 1) {
      const btn = el("button", "", `Advance to “${STAGES[r.stage + 1]}” →`);
      btn.type = "button";
      btn.addEventListener("click", () => {
        requests[index].stage++;
        save("redrelay.requests", requests);
        displayRequests();
      });
      card.append(btn);
    }
    return card;
  }));
}

// Live search
$("searchBtn").addEventListener("click", searchDonors);
$("bloodFilter").addEventListener("change", searchDonors);
$("cityFilter").addEventListener("input", searchDonors);

// Donor registration
$("donorForm").addEventListener("submit", function (event) {
  event.preventDefault();
  const name = $("donorName").value.trim();
  const age = Number($("donorAge").value);
  const blood = $("donorBlood").value;
  const city = $("donorCity").value.trim();
  const message = $("donorMessage");

  if (!name || !blood || !city) { message.textContent = "Please fill all details."; return; }
  if (!Number.isInteger(age) || age < 18 || age > 100) {
    message.textContent = "Registration demo is limited to adults aged 18+.";
    return;
  }
  if (donors.some(d => d.name.toLowerCase() === name.toLowerCase() &&
      d.blood === blood && d.city.toLowerCase() === city.toLowerCase())) {
    message.textContent = "This sample profile is already registered.";
    return;
  }

  donors.push({ name, blood, city }); // age is validated but never stored (privacy)
  save("redrelay.donors", donors);
  message.textContent = "Demo registration successful! Profile added.";
  this.reset();
  searchDonors();
  updateDonorCount();
});

// Emergency request
$("requestForm").addEventListener("submit", function (event) {
  event.preventDefault();
  const request = {
    patient: $("patientName").value.trim(),
    hospital: $("hospital").value.trim(),
    blood: $("requestBlood").value,
    units: Number($("units").value),
    city: $("requestCity").value.trim(),
    stage: 0
  };

  if (!request.patient || !request.hospital || !request.blood || !request.city ||
      !Number.isInteger(request.units) || request.units < 1 || request.units > 10) {
    $("requestMessage").textContent = "Please enter valid request details.";
    return;
  }

  requests.unshift(request);
  save("redrelay.requests", requests);
  displayRequests();
  $("requestMessage").textContent =
    "Demo request created successfully! No hospital or donor was contacted.";
  this.reset();
});

searchDonors();
displayRequests();
updateDonorCount();
