const compatibility={
 'A+':['A+','A-','O+','O-'],'A-':['A-','O-'],
 'B+':['B+','B-','O+','O-'],'B-':['B-','O-'],
 'AB+':['A+','A-','B+','B-','AB+','AB-','O+','O-'],
 'AB-':['A-','B-','AB-','O-'],'O+':['O+','O-'],'O-':['O-']
};
// Donor groups are red-cell donor -> recipient groups.
const donors=[
{name:'Ananya R.',group:'O+',locality:'Medchal',available:true},
{name:'Rahul K.',group:'B-',locality:'Kompally',available:true},
{name:'Sana M.',group:'A+',locality:'Maisammaguda',available:true},
{name:'Vikram S.',group:'O-',locality:'Kandlakoya',available:true},
{name:'Priya N.',group:'AB+',locality:'Medchal',available:false},
{name:'Arjun P.',group:'B+',locality:'Dhulapally',available:true}
];
let requests=[
{id:1,patient:'Patient A',group:'B+',hospital:'Apollo Hospital · Hyderabad',units:2,committed:1,deadline:'Within 4 hours',urgency:'CRITICAL',status:'Donors Responded'},
{id:2,patient:'Patient B',group:'O-',hospital:'Sunshine Hospital · Secunderabad',units:3,committed:0,deadline:'Within 6 hours',urgency:'URGENT',status:'Open / Broadcasted'},
{id:3,patient:'Patient C',group:'A+',hospital:'Malla Reddy Hospital · Suraram',units:2,committed:1,deadline:'Within 8 hours',urgency:'URGENT',status:'Donors Responded'},
{id:4,patient:'Patient D',group:'AB-',hospital:'City Care Hospital · Hyderabad',units:1,committed:0,deadline:'Today',urgency:'NORMAL',status:'Open / Broadcasted'},
{id:5,patient:'Patient E',group:'O+',hospital:'Care Hospital · Hitech City',units:2,committed:2,deadline:'Within 2 hours',urgency:'CRITICAL',status:'Fulfilled / In Transit'}
];
const $=s=>document.querySelector(s);
function renderRequests(){
 $('#requestList').innerHTML=requests.map(r=>`<article class="request-card">
 <div class="request-top"><div class="request-title"><div class="blood">${r.group}</div><div><h3>${escapeHtml(r.patient)} · ${r.units} unit${r.units>1?'s':''} required</h3><p>⌖ ${escapeHtml(r.hospital)}</p></div></div><span class="urgent ${r.urgency==='NORMAL'?'normal':''}">${r.urgency}</span></div>
 <div class="request-meta"><span>◷ ${escapeHtml(r.deadline)}</span><span>♧ ${r.status}</span></div>
 <div class="progress-line"><span style="width:${Math.min(100,r.committed/r.units*100)}%"></span></div>
 <div class="progress-label"><span>${r.committed}/${r.units} units committed</span><span>${Math.round(r.committed/r.units*100)}%</span></div>
 <div class="request-actions"><button class="text-btn" onclick="showMatches(${r.id})">View compatible donors</button><button class="small-btn" onclick="respond(${r.id})">I can donate</button></div></article>`).join('');
 $('#activeCount').textContent=String(requests.filter(r=>r.status!=='Fulfilled / In Transit'&&r.status!=='Closed').length).padStart(2,'0');
 $('#unitCount').textContent=String(requests.reduce((n,r)=>n+r.committed,0)).padStart(2,'0');
}
function renderDonors(){
 $('#donorList').innerHTML=donors.slice(0,6).map(d=>`<div class="donor"><div class="avatar">${d.name.split(' ').map(x=>x[0]).join('')}</div><div class="donor-info"><strong>${escapeHtml(d.name)}</strong><small>${escapeHtml(d.locality)} · ${d.available?'Available':'Unavailable'}</small></div><span class="donor-group">${d.group}</span><i class="available" style="background:${d.available?'#16a477':'#c4cbd1'}"></i></div>`).join('');
 $('#donorCount').textContent=String(30+Math.max(0,donors.length-6));
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function showToast(msg){let t=$('#toast');t.textContent=msg;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2800);}
function showMatches(id){let r=requests.find(x=>x.id===id);let matches=donors.filter(d=>d.available&&compatibility[d.group]?.includes(r.group));showToast(matches.length?`${matches.length} compatible sample donor(s): ${matches.map(x=>x.group+' · '+x.locality).join(', ')}`:'No available sample donors matched.');}
function respond(id){let r=requests.find(x=>x.id===id);if(r.committed>=r.units){showToast('All requested units are already committed.');return;}r.committed++;r.status=r.committed>=r.units?'Fulfilled / In Transit':'Donors Responded';renderRequests();showToast('Demo response recorded. Donor contact remains private.');}
function openModal(id){$('#'+id).classList.add('show')}function closeModal(id){$('#'+id).classList.remove('show')}
document.querySelectorAll('.modal-backdrop').forEach(m=>m.addEventListener('click',e=>{if(e.target===m)m.classList.remove('show')}));
$('#requestForm').addEventListener('submit',e=>{e.preventDefault();let f=new FormData(e.target);let deadline=new Date(f.get('deadline'));let now=new Date();if(!(deadline>now)){ $('#requestMessage').textContent='Please choose a future urgency deadline.';return;}
requests.unshift({id:Date.now(),patient:f.get('patient'),group:f.get('group'),hospital:f.get('hospital'),units:Number(f.get('units')),committed:0,deadline:'Deadline '+deadline.toLocaleString(),urgency:'URGENT',status:'Open / Broadcasted'});
renderRequests();$('#requestMessage').textContent='Demo request added to the broadcast feed.';e.target.reset();showToast('Emergency request added to the feed.');});
$('#donorForm').addEventListener('submit',e=>{e.preventDefault();let f=new FormData(e.target);donors.unshift({name:f.get('name'),group:f.get('group'),locality:f.get('locality'),available:f.get('availability')==='Available'});renderDonors();$('#donorMessage').textContent='Donor registered in this browser demo. Your phone number is not displayed.';e.target.reset();showToast('Thank you for volunteering.');setTimeout(()=>closeModal('donorModal'),1100);});
renderRequests();renderDonors();
